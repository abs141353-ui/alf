/**
 * منصة صندوق أسرة آل عساف — الخادم (Google Apps Script)
 * البيانات: ملف Google Sheets المرتبط بهذا المشروع (أوراق: الأعضاء، حركة الصندوق، الإعدادات).
 * كلمة مرور المشرف: تُحفظ في Script Properties باسم ADMIN_PASSWORD — لا تكتبها في الكود.
 * التفاصيل الكاملة في README.md.
 */
const SH = { members: 'الأعضاء', ledger: 'حركة الصندوق', settings: 'الإعدادات' };
const M_HEAD = ['id', '#', 'الاسم', 'الأسرة', 'الاشتراك', 'سنة الانضمام', 'ملاحظة', 'مستحق معدّل'];
const L_HEAD = ['id', 'الترتيب', 'التاريخ', 'النوع', 'المبلغ', 'البيان', 'التصنيف', 'ملاحظة', 'يؤثر على الرصيد', 'رقم العضو'];

function doGet() {
  let title = 'صندوق الأسرة';
  try { title = readSettings_().fundName || title; } catch (e) {}
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle(title)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/* ---------- صلاحيات ---------- */
const MAX_FAILS = 10, LOCK_SECONDS = 600;
function adminPassword_() {
  return PropertiesService.getScriptProperties().getProperty('ADMIN_PASSWORD') || '';
}
function ownerSession_() {
  try {
    const a = Session.getActiveUser().getEmail(), o = Session.getEffectiveUser().getEmail();
    return !!a && a === o;
  } catch (e) { return false; }
}
function isAdmin_(pw) {
  if (pw) {
    const cache = CacheService.getScriptCache();
    const fails = Number(cache.get('login_fails') || 0);
    const real = adminPassword_();
    if (fails < MAX_FAILS && real.length >= 8 && String(pw) === real) return true;
    if (fails < MAX_FAILS) cache.put('login_fails', String(fails + 1), LOCK_SECONDS);
  }
  return ownerSession_();
}
function requireAdmin_(pw) {
  if (!isAdmin_(pw)) throw new Error('هذه العملية للمشرف فقط');
}
function withLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return fn(); } finally { lock.releaseLock(); }
}

/* ---------- قراءة وكتابة ---------- */
function sheet_(name) {
  const ss = SpreadsheetApp.getActive();
  return ss.getSheetByName(name) || ss.insertSheet(name);
}
function newId_() { return Utilities.getUuid().replace(/-/g, '').slice(0, 10); }
function num_(v) { const n = Number(v); return isNaN(n) ? 0 : n; }
function iso_(v) {
  if (v instanceof Date) return Utilities.formatDate(v, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  return v ? String(v) : '';
}

function readSettings_() {
  const rows = sheet_(SH.settings).getDataRange().getValues();
  const s = { fundName: 'صندوق الأسرة', paymentNote: '', showAll: true, years: [], openingBalance: 0, openingLabel: 'الرصيد الأساسي' };
  rows.forEach(function (r) {
    const k = String(r[0] || '').trim(), v = r[1];
    if (k === 'fundName' || k === 'paymentNote' || k === 'openingLabel') s[k] = v === '' ? s[k] : String(v);
    else if (k === 'openingBalance') s[k] = num_(v);
    else if (k === 'showAll') s[k] = !(v === false || String(v).toLowerCase() === 'false' || v === 'لا');
    else if (k === 'years') { try { s.years = JSON.parse(v); } catch (e) {} }
  });
  return s;
}
function writeSettings_(s) {
  const sh = sheet_(SH.settings);
  sh.clear();
  const rows = [
    ['المفتاح', 'القيمة', 'الوصف'],
    ['fundName', s.fundName, 'اسم الصندوق'],
    ['openingBalance', s.openingBalance, 'الرصيد الأساسي (لا يظهر للمشاركين)'],
    ['openingLabel', s.openingLabel, 'وصف الرصيد الأساسي'],
    ['paymentNote', s.paymentNote, 'تعليمات السداد للمشاركين'],
    ['showAll', s.showAll ? 'true' : 'false', 'إظهار جدول كل الأعضاء للمشاركين'],
    ['years', JSON.stringify(s.years), 'الأعوام (عدّلها من المنصة)']
  ];
  sh.getRange(1, 1, rows.length, 3).setValues(rows);
  sh.getRange('A1:C1').setFontWeight('bold');
  sh.setRightToLeft(true);
}

function readMembers_() {
  const sh = sheet_(SH.members);
  const v = sh.getDataRange().getValues();
  if (v.length < 2) return [];
  const head = v[0].map(String);
  const yearCols = [];
  head.forEach(function (h, i) { if (/^\d{4}$/.test(h.trim())) yearCols.push([h.trim(), i]); });
  const out = [];
  let fixed = false;
  for (let r = 1; r < v.length; r++) {
    const row = v[r];
    const name = String(row[2] || '').trim();
    if (!name) continue;
    let id = String(row[0] || '').trim();
    if (!id) { id = newId_(); sh.getRange(r + 1, 1).setValue(id); fixed = true; }
    const m = { id: id, n: num_(row[1]) || r, name: name, group: String(row[3] || '').trim(), fee: num_(row[4]), note: String(row[6] || ''), pay: {} };
    if (row[5]) m.join = num_(row[5]);
    if (row[7]) { try { m.due = JSON.parse(row[7]); } catch (e) {} }
    yearCols.forEach(function (yc) { const p = num_(row[yc[1]]); if (p > 0) m.pay[yc[0]] = p; });
    out.push(m);
  }
  if (fixed) SpreadsheetApp.flush();
  return out;
}
function writeMembers_(members, years) {
  const ys = {};
  years.forEach(function (y) { ys[String(y.y)] = 1; });
  members.forEach(function (m) { Object.keys(m.pay || {}).forEach(function (y) { ys[y] = 1; }); });
  const yl = Object.keys(ys).sort();
  members = members.slice().sort(function (a, b) { return (a.n || 0) - (b.n || 0); });
  const rows = [M_HEAD.concat(yl)];
  members.forEach(function (m) {
    rows.push([m.id, m.n || '', m.name, m.group || '', m.fee || 0, m.join || '', m.note || '',
      m.due && Object.keys(m.due).length ? JSON.stringify(m.due) : ''].concat(yl.map(function (y) { return (m.pay && m.pay[y]) || ''; })));
  });
  const sh = sheet_(SH.members);
  sh.clear();
  sh.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
  sh.getRange(1, 1, 1, rows[0].length).setFontWeight('bold');
  sh.setFrozenRows(1);
  sh.setRightToLeft(true);
}

function readLedger_() {
  const v = sheet_(SH.ledger).getDataRange().getValues();
  const out = [];
  for (let r = 1; r < v.length; r++) {
    const row = v[r];
    if (!row[4] && !row[5]) continue;
    out.push({ id: String(row[0] || ('row' + r)), order: num_(row[1]) || r, date: iso_(row[2]),
      type: row[3] === 'مصروف' ? 'out' : 'in', amount: Math.abs(num_(row[4])), desc: String(row[5] || ''),
      cat: String(row[6] || ''), note: String(row[7] || ''), inBalance: row[8] === 'نعم' || row[8] === true,
      memberId: String(row[9] || '') });
  }
  return out;
}
function writeLedger_(list) {
  list = list.slice().sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
  const rows = [L_HEAD];
  list.forEach(function (t) {
    rows.push([t.id, t.order, t.date ? "'" + t.date : '', t.type === 'out' ? 'مصروف' : 'إيداع', num_(t.amount), t.desc || '',
      t.cat || '', t.note || '', t.inBalance ? 'نعم' : 'لا', t.memberId || '']);
  });
  const sh = sheet_(SH.ledger);
  sh.clear();
  sh.getRange(1, 1, rows.length, L_HEAD.length).setValues(rows);
  sh.getRange(1, 1, 1, L_HEAD.length).setFontWeight('bold');
  sh.setFrozenRows(1);
  sh.setRightToLeft(true);
}

/* ---------- واجهة برمجية للصفحة ---------- */
function getState(pw) {
  const admin = isAdmin_(pw);
  const s = readSettings_();
  const members = readMembers_();
  const st = {
    admin: admin,
    settings: { fundName: s.fundName, paymentNote: s.paymentNote, showAll: s.showAll, years: s.years },
    members: admin ? members : members.map(function (m) { const c = Object.assign({}, m); delete c.note; return c; })
  };
  if (admin) {
    st.ledger = readLedger_();
    st.finance = { openingBalance: s.openingBalance, openingLabel: s.openingLabel };
    const ss = SpreadsheetApp.getActive();
    st.sheetUrl = ss.getUrl();
    st.xlsxUrl = 'https://docs.google.com/spreadsheets/d/' + ss.getId() + '/export?format=xlsx';
  }
  return st;
}
function checkLogin(pw) {
  const locked = Number(CacheService.getScriptCache().get('login_fails') || 0) >= MAX_FAILS;
  return { ok: isAdmin_(pw), locked: locked };
}

function saveMember(pw, id, body, tx) {
  requireAdmin_(pw);
  withLock_(function () {
    const s = readSettings_();
    const ms = readMembers_();
    const clean = { name: String(body.name || '').trim(), fee: num_(body.fee), group: String(body.group || ''), note: String(body.note || ''), pay: body.pay || {} };
    if (!clean.name) throw new Error('اسم العضو مطلوب');
    if (body.join) clean.join = num_(body.join);
    if (body.due && Object.keys(body.due).length) clean.due = body.due;
    let mid = id;
    const i = id ? ms.findIndex(function (m) { return m.id === id; }) : -1;
    if (i >= 0) { clean.id = id; clean.n = ms[i].n; ms[i] = clean; }
    else { mid = newId_(); clean.id = mid; clean.n = ms.reduce(function (a, m) { return Math.max(a, m.n || 0); }, 0) + 1; ms.push(clean); }
    writeMembers_(ms, s.years);
    if (tx && num_(tx.amount) > 0) {
      const l = readLedger_();
      l.push({ id: newId_(), order: Date.now(), date: tx.date || '', type: 'in', amount: num_(tx.amount), desc: tx.desc || '',
        cat: 'اشتراك', note: '', inBalance: true, memberId: mid });
      writeLedger_(l);
    }
  });
  return getState(pw);
}
function deleteMember(pw, id) {
  requireAdmin_(pw);
  withLock_(function () { writeMembers_(readMembers_().filter(function (m) { return m.id !== id; }), readSettings_().years); });
  return getState(pw);
}
function saveTx(pw, id, body) {
  requireAdmin_(pw);
  withLock_(function () {
    const l = readLedger_();
    const t = { order: num_(body.order) || Date.now(), date: body.date || '', type: body.type === 'out' ? 'out' : 'in', amount: num_(body.amount),
      desc: String(body.desc || ''), cat: String(body.cat || ''), note: String(body.note || ''), inBalance: !!body.inBalance, memberId: body.memberId || '' };
    const i = id ? l.findIndex(function (x) { return x.id === id; }) : -1;
    if (i >= 0) { t.id = id; l[i] = t; } else { t.id = newId_(); l.push(t); }
    writeLedger_(l);
  });
  return getState(pw);
}
function deleteTx(pw, id) {
  requireAdmin_(pw);
  withLock_(function () { writeLedger_(readLedger_().filter(function (t) { return t.id !== id; })); });
  return getState(pw);
}
function saveSettings(pw, patch) {
  requireAdmin_(pw);
  withLock_(function () {
    const s = readSettings_();
    ['fundName', 'paymentNote', 'showAll', 'years', 'openingBalance', 'openingLabel'].forEach(function (k) { if (k in patch) s[k] = patch[k]; });
    s.openingBalance = num_(s.openingBalance);
    writeSettings_(s);
    if ('years' in patch) writeMembers_(readMembers_(), s.years);
  });
  return getState(pw);
}

/* ---------- الإعداد الأول (مرة واحدة) ---------- */
function setup() {
  if (adminPassword_().length < 8) {
    throw new Error('أضف كلمة مرور المشرف أولاً: Project Settings > Script Properties > ADMIN_PASSWORD (8 أحرف على الأقل).');
  }
  if (readMembers_().length) throw new Error('البيانات موجودة مسبقاً — لم يتم تغيير شيء.');
  if (typeof SEED === 'undefined') throw new Error('ملف Seed.gs غير موجود في المشروع.');
  writeSettings_(SEED.settings);
  writeMembers_(SEED.members, SEED.settings.years);
  writeLedger_(SEED.ledger);
  const ss = SpreadsheetApp.getActive();
  ['Sheet1', 'الورقة1', 'ورقة1', 'الورقة 1'].forEach(function (n) {
    const extra = ss.getSheetByName(n);
    if (extra && ss.getSheets().length > 1) ss.deleteSheet(extra);
  });
  const msg = 'تم الإعداد: ' + SEED.members.length + ' عضو و ' + SEED.ledger.length + ' حركة';
  Logger.log(msg);
  return msg;
}

/* فحص سريع بعد النشر: شغّلها من المحرر وراجع السجل (Execution log) */
function selfTest() {
  const st = getState('');
  Logger.log('أعضاء: ' + st.members.length + ' | يظهر الرصيد للزائر؟ ' + ('finance' in st) + ' | كلمة المرور مضبوطة؟ ' + (adminPassword_().length >= 8));
}
